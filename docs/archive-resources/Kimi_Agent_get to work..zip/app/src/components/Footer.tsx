import { Link } from 'react-router-dom'
import { Facebook, Instagram, Youtube } from 'lucide-react'

const movementLinks = [
  { label: 'Aims & Objectives', path: '/our-agenda' },
  { label: 'Chapters', path: '/chapters' },
  { label: 'Members', path: '/members' },
  { label: 'Donate', path: '/donate' },
  { label: 'Impact', path: '/impact' },
]

const connectLinks = [
  { label: 'Join', path: '/register' },
  { label: 'Sign In', path: '/login' },
  { label: 'Privacy Agreement', path: '/privacy' },
  { label: 'Facebook', path: '#' },
  { label: 'Instagram', path: '#' },
  { label: 'TikTok', path: '#' },
  { label: 'YouTube', path: '#' },
]

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <img src="/logo.png" alt="The Base" className="h-10 w-auto" />
              <div>
                <h3 className="font-bold text-[#1a1a1a]">THE BASE</h3>
                <p className="text-xs text-[#D4A017] font-medium">Ghana First, Jobs for the youth!</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed">
              A global political movement connecting Ghanaians and friends of Ghana worldwide. Building community, driving progress.
            </p>
            <div className="flex items-center gap-3">
              <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.88-2.89 2.89 2.89 0 012.88-2.89c.23 0 .45.03.66.08V9.4a6.37 6.37 0 00-.66-.04A6.34 6.34 0 003.5 15.7a6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.92a8.35 8.35 0 004.89 1.56V7.15a4.92 4.92 0 01-1.48-.46z"/></svg>
              </a>
              <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors">
                <Youtube className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Movement */}
          <div>
            <h4 className="font-semibold text-[#1a1a1a] mb-4">Movement</h4>
            <ul className="space-y-2">
              {movementLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.path}
                    className="text-sm text-gray-600 hover:text-[#006B3C] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="font-semibold text-[#1a1a1a] mb-4">Connect</h4>
            <ul className="space-y-2">
              {connectLinks.map((link) => (
                <li key={link.label}>
                  {link.path === '#' ? (
                    <a
                      href={link.path}
                      className="text-sm text-gray-600 hover:text-[#006B3C] transition-colors"
                    >
                      {link.label}
                    </a>
                  ) : (
                    <Link
                      to={link.path}
                      className="text-sm text-gray-600 hover:text-[#006B3C] transition-colors"
                    >
                      {link.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 pt-6 border-t flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-500">
            &copy; 2026 The Base. All rights reserved.
          </p>
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 rounded-sm bg-[#CE1126]"></div>
            <div className="w-4 h-4 rounded-sm bg-[#F6B800]"></div>
            <div className="w-4 h-4 rounded-sm bg-[#006B3C]"></div>
          </div>
        </div>
      </div>
    </footer>
  )
}
