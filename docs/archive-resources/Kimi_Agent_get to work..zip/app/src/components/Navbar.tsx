import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, Home, BookOpen, UserPlus, Store, Heart, LogIn, Phone, Shield, Share2 } from 'lucide-react'
import { Button } from '@/components/ui/button'

const navLinks = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/our-agenda', label: 'Our Agenda', icon: BookOpen },
  { path: '/register', label: 'Register', icon: UserPlus },
  { path: '/store', label: 'Store', icon: Store },
  { path: '/donate', label: 'Donate', icon: Heart },
  { path: '/login', label: 'Login', icon: LogIn },
  { path: '/contact', label: 'Contact Us', icon: Phone },
  { path: '/admin-login', label: 'Admin Login', icon: Shield },
]

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    setIsOpen(false)
  }, [location.pathname])

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-white'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <img src="/logo.png" alt="The Base" className="h-10 w-auto" />
            <span className="text-lg font-bold tracking-wide text-[#1a1a1a] hidden sm:inline">
              THE BASE
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon
              const isActive = location.pathname === link.path
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#006B3C] bg-[#006B3C]/10'
                      : 'text-gray-700 hover:text-[#006B3C] hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {link.label}
                </Link>
              )
            })}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:flex items-center gap-3">
            <Button
              asChild
              className="bg-[#006B3C] hover:bg-[#005a32] text-white font-semibold px-4 py-2 rounded-md"
            >
              <Link to="/register" className="flex items-center gap-2">
                <Share2 className="w-4 h-4" />
                Invite & Share
              </Link>
            </Button>
          </div>

          {/* Mobile Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t shadow-lg">
          <div className="px-4 py-3 space-y-1">
            {navLinks.map((link) => {
              const Icon = link.icon
              const isActive = location.pathname === link.path
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-3 px-3 py-3 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'text-[#006B3C] bg-[#006B3C]/10'
                      : 'text-gray-700 hover:text-[#006B3C] hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {link.label}
                </Link>
              )
            })}
            <div className="pt-2">
              <Button
                asChild
                className="w-full bg-[#006B3C] hover:bg-[#005a32] text-white font-semibold"
              >
                <Link to="/register" className="flex items-center justify-center gap-2">
                  <Share2 className="w-4 h-4" />
                  Invite & Share
                </Link>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
