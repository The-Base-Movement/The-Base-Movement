import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import OurAgenda from './pages/OurAgenda'
import Register from './pages/Register'
import Contact from './pages/Contact'
import Donate from './pages/Donate'
import Login from './pages/Login'
import Members from './pages/Members'
import Dashboard from './pages/Dashboard'
import Store from './pages/Store'
import Impact from './pages/Impact'
import Chapters from './pages/Chapters'
import Privacy from './pages/Privacy'
import AdminLogin from './pages/AdminLogin'

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/our-agenda" element={<OurAgenda />} />
          <Route path="/register" element={<Register />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/donate" element={<Donate />} />
          <Route path="/login" element={<Login />} />
          <Route path="/members" element={<Members />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/store" element={<Store />} />
          <Route path="/impact" element={<Impact />} />
          <Route path="/chapters" element={<Chapters />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/admin-login" element={<AdminLogin />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
