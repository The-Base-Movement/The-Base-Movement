import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  ArrowRight,
  Download,
  Share2,
  Mail,
  Facebook,
  Instagram,
  Youtube,
  Eye,
  Target,
  ShieldCheck,
  MapPin,
  Globe,
  BookOpen,
  Heart
} from 'lucide-react'

function AnimatedCounter({ target, duration = 2000 }: { target: number; duration?: number }) {
  const [count, setCount] = useState(0)
  const ref = useRef<HTMLDivElement>(null)
  const [started, setStarted] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started) {
          setStarted(true)
        }
      },
      { threshold: 0.5 }
    )
    if (ref.current) observer.observe(ref.current)
    return () => observer.disconnect()
  }, [started])

  useEffect(() => {
    if (!started) return
    let start = 0
    const increment = target / (duration / 16)
    const timer = setInterval(() => {
      start += increment
      if (start >= target) {
        setCount(target)
        clearInterval(timer)
      } else {
        setCount(Math.floor(start))
      }
    }, 16)
    return () => clearInterval(timer)
  }, [started, target, duration])

  return (
    <div ref={ref} className="text-4xl md:text-5xl font-bold text-[#D4A017]">
      {count.toLocaleString()}
    </div>
  )
}

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <section className="hero-gradient text-white py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-6">
            <img src="/logo.png" alt="The Base" className="h-32 md:h-40 w-auto drop-shadow-lg" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold mb-2 tracking-wide">THE BASE</h1>
          <div className="section-divider mx-auto mb-6"></div>
          <p className="text-xl md:text-2xl text-[#F6B800] font-semibold mb-4">
            Ghana First, Jobs for the youth!
          </p>
          <p className="text-base md:text-lg text-gray-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            A global movement uniting people worldwide to build a stronger, more prosperous Ghana. Register for Base Ghana or Base Diaspora and be part of the change.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
            <Button
              asChild
              className="bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold px-6 py-3 text-base rounded-md"
            >
              <Link to="/register" className="flex items-center gap-2">
                Register Now <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 font-semibold px-6 py-3 text-base rounded-md"
            >
              <Link to="/register" className="flex items-center gap-2">
                <Download className="w-4 h-4" /> Download Form
              </Link>
            </Button>
            <Button
              asChild
              variant="ghost"
              className="text-white hover:bg-white/10 font-semibold px-4 py-3 text-base"
            >
              <Link to="/register" className="flex items-center gap-2">
                <Share2 className="w-4 h-4" /> Invite & Share
              </Link>
            </Button>
            <Button
              asChild
              variant="ghost"
              className="text-white hover:bg-white/10 font-semibold px-4 py-3 text-base"
            >
              <Link to="/contact" className="flex items-center gap-2">
                <Mail className="w-4 h-4" /> Contact Us
              </Link>
            </Button>
          </div>
          <div className="flex items-center justify-center gap-4">
            <span className="text-sm text-gray-400">Follow us:</span>
            <a href="#" className="text-gray-400 hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.88-2.89 2.89 2.89 0 012.88-2.89c.23 0 .45.03.66.08V9.4a6.37 6.37 0 00-.66-.04A6.34 6.34 0 003.5 15.7a6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.92a8.35 8.35 0 004.89 1.56V7.15a4.92 4.92 0 01-1.48-.46z"/></svg>
            </a>
            <a href="#" className="text-gray-400 hover:text-white transition-colors"><Youtube className="w-5 h-5" /></a>
          </div>
        </div>
      </section>

      {/* Ghana vs Diaspora Cards */}
      <section className="py-16 md:py-20 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-12 h-12 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-6 h-6 text-[#006B3C]" />
                </div>
                <h3 className="text-xl font-bold text-[#1a1a1a] mb-2">Base Ghana</h3>
                <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                  For Ghanaians living in Ghana. Join our grassroots movement and make your voice heard in the development of our great nation.
                </p>
                <Button
                  asChild
                  className="bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold"
                >
                  <Link to="/register?platform=GHANA">Register - Base Ghana</Link>
                </Button>
              </CardContent>
            </Card>
            <Card className="border border-gray-200 hover:border-[#D4A017]/30 hover:shadow-lg transition-all duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-12 h-12 bg-[#D4A017]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-6 h-6 text-[#D4A017]" />
                </div>
                <h3 className="text-xl font-bold text-[#1a1a1a] mb-2">Base Diaspora</h3>
                <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                  For Ghanaians and friends of Ghana living abroad. Stay connected and contribute to Ghana's progress from anywhere in the world.
                </p>
                <Button
                  asChild
                  className="bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold"
                >
                  <Link to="/register?platform=DIASPORA">Register - Base Diaspora</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Vision, Mission, Values */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#1a1a1a] mb-12">
            Our Vision, Mission & Values
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="border border-gray-200 hover:shadow-md transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye className="w-6 h-6 text-[#006B3C]" />
                </div>
                <h3 className="text-lg font-bold text-[#1a1a1a] mb-3">Our Vision</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  A Ghana with quality education, lean accountable government, industrialisation, tourism, and agro-processing, quality infrastructure, comprehensive institutional reform, and expertise-led agriculture.
                </p>
              </CardContent>
            </Card>
            <Card className="border border-gray-200 hover:shadow-md transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-[#D4A017]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-6 h-6 text-[#D4A017]" />
                </div>
                <h3 className="text-lg font-bold text-[#1a1a1a] mb-3">Our Mission</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  To deliver an honest, detailed, and actionable agenda rooted in the realities of ordinary Ghanaians — covering education, governance, industrialisation, infrastructure, institutional reform, and agriculture.
                </p>
              </CardContent>
            </Card>
            <Card className="border border-gray-200 hover:shadow-md transition-all duration-300">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-[#CE1126]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <ShieldCheck className="w-6 h-6 text-[#CE1126]" />
                </div>
                <h3 className="text-lg font-bold text-[#1a1a1a] mb-3">Our Values</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  Patriotism, Honesty, and Discipline. We are guided by love of country, transparency in leadership, and the moral courage to do what is right for Ghana.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 md:py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-8 text-center">
            <div>
              <AnimatedCounter target={355482} />
              <p className="text-sm text-gray-600 mt-2 font-medium">People Joined</p>
            </div>
            <div>
              <AnimatedCounter target={2} />
              <p className="text-sm text-gray-600 mt-2 font-medium">Platforms (Ghana & Diaspora)</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-20 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="w-12 h-12 bg-[#D4A017]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-6 h-6 text-[#D4A017]" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-[#1a1a1a] mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-gray-600 mb-8 leading-relaxed">
            Join over 355,482 people who are building a better future for Ghana. Your voice, your community, your movement.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4 mb-8">
            <Button
              asChild
              className="bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold px-6 py-3 text-base rounded-md"
            >
              <Link to="/register" className="flex items-center gap-2">
                Register Now <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              className="border-[#006B3C] text-[#006B3C] hover:bg-[#006B3C]/10 font-semibold px-6 py-3 text-base rounded-md"
            >
              <Link to="/our-agenda" className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" /> Our Agenda
              </Link>
            </Button>
          </div>
          <div className="flex items-center justify-center gap-4">
            <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors"><Facebook className="w-5 h-5" /></a>
            <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors"><Instagram className="w-5 h-5" /></a>
            <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.88-2.89 2.89 2.89 0 012.88-2.89c.23 0 .45.03.66.08V9.4a6.37 6.37 0 00-.66-.04A6.34 6.34 0 003.5 15.7a6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.34-6.34V8.92a8.35 8.35 0 004.89 1.56V7.15a4.92 4.92 0 01-1.48-.46z"/></svg>
            </a>
            <a href="#" className="text-gray-500 hover:text-[#006B3C] transition-colors"><Youtube className="w-5 h-5" /></a>
          </div>
        </div>
      </section>
    </div>
  )
}
