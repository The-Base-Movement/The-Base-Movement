import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Heart, Phone, Upload, ArrowRight, Link2, Check } from 'lucide-react'

export default function Donate() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="The Base" className="h-16 w-auto mx-auto mb-4" />
          <h1 className="text-2xl md:text-3xl font-bold text-[#006B3C] mb-2">
            Donate / Support the Movement
          </h1>
          <p className="text-gray-600">
            Your contribution helps grow and sustain The Base movement across Ghana and the diaspora.
          </p>
        </div>

        {submitted ? (
          <Card className="border border-gray-200">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-[#006B3C]" />
              </div>
              <h2 className="text-2xl font-bold text-[#1a1a1a] mb-2">Thank You!</h2>
              <p className="text-gray-600 mb-4">
                Your donation has been recorded and will be verified shortly.
              </p>
              <Button asChild className="bg-[#006B3C] hover:bg-[#005a32] text-white">
                <Link to="/">Back to Home</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* MoMo Payment Details */}
            <Card className="border border-gray-200 mb-6">
              <CardContent className="p-6">
                <div className="flex items-center gap-2 mb-4">
                  <Phone className="w-5 h-5 text-[#006B3C]" />
                  <h3 className="font-semibold text-[#1a1a1a]">MoMo Payment Details</h3>
                </div>
                <div className="space-y-2 text-sm">
                  <p className="font-semibold text-[#006B3C]">Paul Kofi Agyekum</p>
                  <p className="font-mono text-[#006B3C]">+233 538 873 569</p>
                  <p className="text-gray-600">Ashanti Region - Ejisu</p>
                  <p className="text-gray-600">Reference: <span className="font-semibold">"The base"</span></p>
                  <p className="text-xs text-gray-500 mt-2">
                    Send your donation via MoMo, then fill in the form below and upload your receipt.
                  </p>
                </div>
              </CardContent>
            </Card>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="fullName" className="text-sm font-medium">
                  Full Name <span className="text-[#CE1126]">*</span>
                </Label>
                <Input id="fullName" placeholder="Enter your full name" required className="mt-1" />
              </div>

              <div>
                <Label htmlFor="phone" className="text-sm font-medium">
                  Phone Number <span className="text-[#CE1126]">*</span>
                </Label>
                <Input id="phone" placeholder="Enter your phone number" required className="mt-1" />
              </div>

              <div>
                <Label htmlFor="email" className="text-sm font-medium">Email (optional)</Label>
                <Input id="email" type="email" placeholder="Enter your email" className="mt-1" />
              </div>

              <div>
                <Label htmlFor="country" className="text-sm font-medium">
                  Country <span className="text-[#CE1126]">*</span>
                </Label>
                <Select required>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select your country" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="GH">Ghana</SelectItem>
                    <SelectItem value="NG">Nigeria</SelectItem>
                    <SelectItem value="UK">United Kingdom</SelectItem>
                    <SelectItem value="US">United States</SelectItem>
                    <SelectItem value="CA">Canada</SelectItem>
                    <SelectItem value="DE">Germany</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="amount" className="text-sm font-medium">
                  Amount (GHS) <span className="text-[#CE1126]">*</span>
                </Label>
                <Input id="amount" type="number" placeholder="Enter amount" required className="mt-1" />
              </div>

              <div>
                <Label htmlFor="message" className="text-sm font-medium">Message (optional)</Label>
                <Textarea id="message" placeholder="Leave a message of support..." rows={3} className="mt-1" />
              </div>

              {/* Link to Membership */}
              <Card className="border border-gray-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Link2 className="w-4 h-4 text-[#006B3C]" />
                    <h4 className="text-sm font-semibold text-[#1a1a1a]">Link to Your Membership (optional)</h4>
                  </div>
                  <p className="text-xs text-gray-500 mb-3">
                    If you are a registered member, enter your membership number to link this donation to your profile.
                  </p>
                  <div>
                    <Label htmlFor="membership" className="text-xs font-medium">Membership Number</Label>
                    <Input id="membership" placeholder="e.g. GH-2028-345501 or DI-2028-345501" className="mt-1" />
                  </div>
                  <div className="flex items-start gap-2 mt-3">
                    <Checkbox id="show-donation" />
                    <Label htmlFor="show-donation" className="text-xs text-gray-600 cursor-pointer">
                      Show my donation on my dashboard once verified
                    </Label>
                  </div>
                </CardContent>
              </Card>

              {/* Upload Receipt */}
              <div>
                <Label className="text-sm font-medium">
                  Upload Receipt / Proof of Payment <span className="text-[#CE1126]">*</span>
                </Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center mt-1">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Click to upload receipt</p>
                  <p className="text-xs text-gray-400">JPG, PNG, or PDF (max 5MB)</p>
                  <Input type="file" accept=".jpg,.jpeg,.png,.pdf" className="hidden" id="receipt" />
                  <Label htmlFor="receipt" className="cursor-pointer inline-block mt-2">
                    <span className="text-[#006B3C] text-sm hover:underline">Choose file</span>
                  </Label>
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-[#006B3C] hover:bg-[#005a32] text-white font-semibold py-3"
              >
                <Heart className="w-4 h-4 mr-2" /> Submit Donation
              </Button>
            </form>

            {/* TapTap Send */}
            <Card className="border border-[#D4A017]/30 bg-[#D4A017]/5 mt-6">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-[#D4A017]/20 rounded-full flex items-center justify-center shrink-0">
                    <ArrowRight className="w-4 h-4 text-[#D4A017]" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-[#D4A017]">Sending from abroad? Use TapTap Send</p>
                    <p className="text-xs text-gray-600 mt-1">
                      Redeem code <span className="font-semibold text-[#006B3C]">THEBASEM</span> and get $10.00 when you send $50.00 or more.
                    </p>
                    <a href="#" className="text-xs text-[#006B3C] hover:underline mt-1 inline-block">
                      Get TapTap Send →
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  )
}
