import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import { Mail, Phone, MapPin, Send } from 'lucide-react'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient text-white py-12 md:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-2">Contact Us</h1>
          <p className="text-gray-300">
            Have a question or want to get involved? Reach out to us.
          </p>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-2xl font-bold text-[#1a1a1a] mb-4">Get In Touch</h2>
              <p className="text-gray-600 mb-8">
                Whether you're in Ghana or the Diaspora, we'd love to hear from you.
              </p>

              <div className="space-y-4">
                <Card className="border border-gray-200">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#006B3C]/10 rounded-full flex items-center justify-center shrink-0">
                      <Mail className="w-5 h-5 text-[#006B3C]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1a1a1a]">Email</p>
                      <p className="text-sm text-gray-600">TheBasemovementgh@gmail.com</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-200">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#006B3C]/10 rounded-full flex items-center justify-center shrink-0">
                      <Phone className="w-5 h-5 text-[#006B3C]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1a1a1a]">Phone</p>
                      <p className="text-sm text-gray-600">Contact us via email for phone inquiries</p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-200">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="w-10 h-10 bg-[#006B3C]/10 rounded-full flex items-center justify-center shrink-0">
                      <MapPin className="w-5 h-5 text-[#006B3C]" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-[#1a1a1a]">Location</p>
                      <p className="text-sm text-gray-600">Ghana & Diaspora</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Form */}
            <div>
              <h2 className="text-2xl font-bold text-[#1a1a1a] mb-6">Send Us a Message</h2>
              {submitted ? (
                <Card className="border border-gray-200">
                  <CardContent className="p-6 text-center">
                    <Send className="w-10 h-10 text-[#006B3C] mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-[#1a1a1a] mb-2">Message Sent!</h3>
                    <p className="text-sm text-gray-600">Thank you for reaching out. We'll get back to you shortly.</p>
                  </CardContent>
                </Card>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="fullName" className="text-sm font-medium">
                      Full Name <span className="text-[#CE1126]">*</span>
                    </Label>
                    <Input id="fullName" placeholder="Your full name" required className="mt-1" />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email" className="text-sm font-medium">Email (optional)</Label>
                      <Input id="email" type="email" placeholder="you@example.com" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-sm font-medium">Phone (optional)</Label>
                      <Input id="phone" placeholder="+233 XX XXX XXXX" className="mt-1" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="platform" className="text-sm font-medium">Platform</Label>
                    <Select>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select your platform" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="GHANA">Base Ghana</SelectItem>
                        <SelectItem value="DIASPORA">Base Diaspora</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-sm font-medium">
                      Message <span className="text-[#CE1126]">*</span>
                    </Label>
                    <Textarea
                      id="message"
                      placeholder="How can we help you?"
                      required
                      rows={5}
                      className="mt-1"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[#D4A017] hover:bg-[#c49a15] text-white font-semibold py-3"
                  >
                    <Send className="w-4 h-4 mr-2" /> Send Message
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
