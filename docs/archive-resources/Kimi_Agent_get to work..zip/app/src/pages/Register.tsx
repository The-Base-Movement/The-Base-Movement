import { useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Card, CardContent } from '@/components/ui/card'
import { ArrowRight, ArrowLeft, FileText, Upload, User, Eye, EyeOff } from 'lucide-react'

const ageRanges = ['16-25', '26-40', '41-60', '60+']
const educationLevels = ['None', 'Primary', 'JHS', 'SHS', 'Vocational', 'Diploma', 'Bachelor', 'Masters', 'PhD']
const ghanaRegions = [
  'Ahafo', 'Ashanti', 'Bono', 'Bono East', 'Central', 'Eastern', 'Greater Accra',
  'North East', 'Northern', 'Oti', 'Savannah', 'Upper East', 'Upper West', 'Volta', 'Western', 'Western North'
]

export default function Register() {
  const [searchParams] = useSearchParams()
  const platformParam = searchParams.get('platform')
  const [step, setStep] = useState<'choice' | 'form' | 'upload'>(platformParam ? 'form' : 'choice')
  const [platform, setPlatform] = useState(platformParam || 'GHANA')
  const [showPassword, setShowPassword] = useState(false)
  const [agreed, setAgreed] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const [formData, setFormData] = useState({
    fullName: '',
    contactNumber: '',
    ageRange: '',
    gender: 'Male',
    password: '',
    email: '',
    residentialAddress: '',
    region: '',
    constituency: '',
    profession: '',
    employment: '',
    educationLevel: '',
    emergencyContactName: '',
    emergencyRelationship: '',
    emergencyNumber: '',
  })

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4">
        <Card className="max-w-lg w-full">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-8 h-8 text-[#006B3C]" />
            </div>
            <h2 className="text-2xl font-bold text-[#1a1a1a] mb-2">Registration Submitted!</h2>
            <p className="text-gray-600 mb-4">
              Thank you for joining The Base. Your application has been received and is being processed.
            </p>
            <p className="text-sm text-gray-500 mb-6">
              You will receive a confirmation message with your membership details shortly.
            </p>
            <div className="flex flex-col gap-3">
              <Button asChild className="bg-[#006B3C] hover:bg-[#005a32] text-white">
                <Link to="/dashboard">Go to Dashboard</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/">Back to Home</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (step === 'choice') {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-lg w-full">
          <div className="text-center mb-8">
            <img src="/logo.png" alt="The Base" className="h-20 w-auto mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-[#CE1126] mb-1">THE BASE</h1>
            <p className="text-sm text-gray-500 mb-1">TheBasemovementgh@gmail.com</p>
            <div className="w-16 h-0.5 bg-[#CE1126] mx-auto mb-4"></div>
            <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Membership Registration Form</h2>
            <p className="text-sm text-gray-500 mt-4">How would you like to register?</p>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => setStep('form')}
              className="w-full flex items-center gap-4 p-5 border-2 border-[#006B3C] rounded-lg hover:bg-[#006B3C]/5 transition-colors text-left"
            >
              <div className="w-12 h-12 bg-[#006B3C]/10 rounded-full flex items-center justify-center shrink-0">
                <FileText className="w-6 h-6 text-[#006B3C]" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-[#1a1a1a]">Register Online</h3>
                <p className="text-sm text-gray-500">Fill in your details on this page. Takes about 5 minutes.</p>
              </div>
              <ArrowRight className="w-5 h-5 text-gray-400" />
            </button>

            <button
              onClick={() => setStep('upload')}
              className="w-full flex items-center gap-4 p-5 border-2 border-[#CE1126] rounded-lg hover:bg-[#CE1126]/5 transition-colors text-left"
            >
              <div className="w-12 h-12 bg-[#CE1126]/10 rounded-full flex items-center justify-center shrink-0">
                <Upload className="w-6 h-6 text-[#CE1126]" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-[#1a1a1a]">Upload Completed Form</h3>
                <p className="text-sm text-gray-500">Already filled a paper form? Upload it and we'll scan it for you.</p>
              </div>
              <ArrowRight className="w-5 h-5 text-gray-400" />
            </button>
          </div>

          <p className="text-center text-sm text-gray-500 mt-6">
            Already a member? <Link to="/login" className="text-[#006B3C] hover:underline font-medium">Sign in here</Link>
          </p>
        </div>
      </div>
    )
  }

  if (step === 'upload') {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-lg w-full">
          <div className="text-center mb-8">
            <img src="/logo.png" alt="The Base" className="h-20 w-auto mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-[#CE1126] mb-1">THE BASE</h1>
            <div className="w-16 h-0.5 bg-[#CE1126] mx-auto mb-4"></div>
            <h2 className="text-lg font-semibold text-gray-700">Upload Completed Form</h2>
          </div>

          <Card className="border-2 border-dashed border-gray-300">
            <CardContent className="p-8 text-center">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">Click to upload your completed registration form</p>
              <p className="text-sm text-gray-400 mb-4">JPG, PNG, or PDF (max 5MB)</p>
              <Input type="file" accept=".jpg,.jpeg,.png,.pdf" className="hidden" id="form-upload" />
              <Label htmlFor="form-upload" className="cursor-pointer">
                <div className="bg-[#006B3C] text-white px-6 py-2 rounded-md inline-block hover:bg-[#005a32] transition-colors">
                  Select File
                </div>
              </Label>
            </CardContent>
          </Card>

          <Button
            variant="ghost"
            className="mt-4 text-gray-500"
            onClick={() => setStep('choice')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to options
          </Button>
        </div>
      </div>
    )
  }

  // Form step
  return (
    <div className="py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="The Base" className="h-20 w-auto mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-[#CE1126] mb-1">THE BASE</h1>
          <p className="text-sm text-gray-500 mb-1">TheBasemovementgh@gmail.com</p>
          <div className="w-16 h-0.5 bg-[#CE1126] mx-auto mb-4"></div>
          <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Membership Registration Form</h2>
          <button
            onClick={() => setStep('choice')}
            className="text-sm text-gray-500 hover:text-[#006B3C] mt-2 flex items-center justify-center gap-1 mx-auto"
          >
            <ArrowLeft className="w-3 h-3" /> Back to registration options
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Required Fields */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="fullName" className="text-sm font-medium">
                Full Name <span className="text-[#CE1126]">*</span>
              </Label>
              <Input
                id="fullName"
                placeholder="Enter your full name"
                required
                value={formData.fullName}
                onChange={(e) => handleChange('fullName', e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label className="text-sm font-medium">
                Platform <span className="text-[#CE1126]">*</span>
              </Label>
              <RadioGroup
                value={platform}
                onValueChange={setPlatform}
                className="flex gap-4 mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="GHANA" id="ghana" />
                  <Label htmlFor="ghana" className="text-sm">Base Ghana</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="DIASPORA" id="diaspora" />
                  <Label htmlFor="diaspora" className="text-sm">Base Diaspora</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="contactNumber" className="text-sm font-medium">
                Contact Number <span className="text-[#CE1126]">*</span>
              </Label>
              <div className="flex gap-2 mt-1">
                <span className="flex items-center px-3 bg-gray-100 border rounded-md text-sm text-gray-600">+233</span>
                <Input
                  id="contactNumber"
                  placeholder="Phone number"
                  required
                  value={formData.contactNumber}
                  onChange={(e) => handleChange('contactNumber', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="ageRange" className="text-sm font-medium">
                Age Range <span className="text-[#CE1126]">*</span>
              </Label>
              <Select value={formData.ageRange} onValueChange={(v) => handleChange('ageRange', v)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select age range" />
                </SelectTrigger>
                <SelectContent>
                  {ageRanges.map((range) => (
                    <SelectItem key={range} value={range}>{range}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-medium">
                Gender <span className="text-[#CE1126]">*</span>
              </Label>
              <RadioGroup
                value={formData.gender}
                onValueChange={(v) => handleChange('gender', v)}
                className="flex gap-4 mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="Male" id="male" />
                  <Label htmlFor="male" className="text-sm">Male</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="Female" id="female" />
                  <Label htmlFor="female" className="text-sm">Female</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="Other" id="other" />
                  <Label htmlFor="other" className="text-sm">Other</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="password" className="text-sm font-medium">
                Password <span className="text-[#CE1126]">*</span>
              </Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Min 6 characters"
                  required
                  minLength={6}
                  value={formData.password}
                  onChange={(e) => handleChange('password', e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>

          {/* Optional Information */}
          <div className="border-t pt-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">Optional Information</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="address" className="text-sm font-medium">Residential Address</Label>
                <Input
                  id="address"
                  placeholder="Your address"
                  value={formData.residentialAddress}
                  onChange={(e) => handleChange('residentialAddress', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="region" className="text-sm font-medium">Region</Label>
                <Select value={formData.region} onValueChange={(v) => handleChange('region', v)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    {ghanaRegions.map((region) => (
                      <SelectItem key={region} value={region}>{region}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="constituency" className="text-sm font-medium">Constituency</Label>
                <Input
                  id="constituency"
                  placeholder="Search constituency..."
                  value={formData.constituency}
                  onChange={(e) => handleChange('constituency', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="profession" className="text-sm font-medium">Profession / Skill</Label>
                <Input
                  id="profession"
                  placeholder="e.g. Teacher, Engineer"
                  value={formData.profession}
                  onChange={(e) => handleChange('profession', e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label className="text-sm font-medium">Employment</Label>
                <RadioGroup
                  value={formData.employment}
                  onValueChange={(v) => handleChange('employment', v)}
                  className="flex gap-4 mt-2"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Yes" id="emp-yes" />
                    <Label htmlFor="emp-yes" className="text-sm">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="No" id="emp-no" />
                    <Label htmlFor="emp-no" className="text-sm">No</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="education" className="text-sm font-medium">Education Level</Label>
                <Select value={formData.educationLevel} onValueChange={(v) => handleChange('educationLevel', v)}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select education level" />
                  </SelectTrigger>
                  <SelectContent>
                    {educationLevels.map((level) => (
                      <SelectItem key={level} value={level}>{level}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="border-t pt-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">Emergency Contact</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="emergencyName" className="text-sm font-medium">Emergency Contact Name</Label>
                <Input
                  id="emergencyName"
                  placeholder="Emergency contact name"
                  value={formData.emergencyContactName}
                  onChange={(e) => handleChange('emergencyContactName', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="relationship" className="text-sm font-medium">Relationship</Label>
                <Input
                  id="relationship"
                  placeholder="e.g. Father, Mother, Sibling"
                  value={formData.emergencyRelationship}
                  onChange={(e) => handleChange('emergencyRelationship', e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="emergencyNumber" className="text-sm font-medium">Contact Number</Label>
                <Input
                  id="emergencyNumber"
                  placeholder="Phone number"
                  value={formData.emergencyNumber}
                  onChange={(e) => handleChange('emergencyNumber', e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
          </div>

          {/* Photo Upload */}
          <div className="border-t pt-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">Photo <span className="text-[#CE1126]">*</span></h3>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600">Upload Photo</p>
              <Input type="file" accept="image/*" className="hidden" id="photo-upload" />
              <Label htmlFor="photo-upload" className="cursor-pointer inline-block mt-2">
                <span className="text-[#006B3C] text-sm hover:underline">Choose file</span>
              </Label>
            </div>
          </div>

          {/* Declaration */}
          <div className="border-t pt-6">
            <div className="bg-[#CE1126]/5 border border-[#CE1126]/20 rounded-lg p-4">
              <h3 className="text-sm font-bold text-[#CE1126] mb-2">DECLARATION</h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                I hereby declare that the information provided in this form is true, accurate and complete to the best of my knowledge. I commit to uphold the values of <strong>THE BASE</strong> — Patriotism, Honesty and Discipline — and to advance the cause of <strong>GHANA FIRST</strong> in all my actions as a member. I understand that my information will be held securely and used solely for THE BASE membership administration.
              </p>
            </div>
            <div className="flex items-start gap-3 mt-4">
              <Checkbox
                id="privacy"
                checked={agreed}
                onCheckedChange={(checked) => setAgreed(checked === true)}
              />
              <Label htmlFor="privacy" className="text-sm text-gray-600 leading-relaxed cursor-pointer">
                I agree to the <Link to="/privacy" className="text-[#CE1126] hover:underline">Privacy Agreement</Link> <span className="text-[#CE1126]">*</span>
              </Label>
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4">
            <Button
              type="submit"
              disabled={!agreed}
              className="w-full bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold py-3 text-base disabled:opacity-50"
            >
              <ArrowRight className="w-4 h-4 mr-2" /> Submit Registration
            </Button>
            <p className="text-center text-sm text-gray-500 mt-4">
              Already have an account? <Link to="/login" className="text-[#006B3C] hover:underline font-medium">Sign in</Link>
            </p>
          </div>
        </form>
      </div>
    </div>
  )
}
