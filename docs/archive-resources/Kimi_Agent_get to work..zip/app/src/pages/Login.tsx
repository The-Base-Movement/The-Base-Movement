import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Eye, EyeOff, ArrowRight } from 'lucide-react'

export default function Login() {
  const [showPassword, setShowPassword] = useState(false)

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full">
        <Card className="border border-gray-200">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <img src="/logo.png" alt="The Base" className="h-16 w-auto mx-auto mb-3" />
              <h1 className="text-xl font-bold text-[#CE1126] mb-1">THE BASE</h1>
              <div className="w-12 h-0.5 bg-[#CE1126] mx-auto mb-3"></div>
              <p className="text-sm text-gray-500">Sign in to your account</p>
            </div>

            <form className="space-y-4">
              <div>
                <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                <Input
                  id="phone"
                  placeholder="e.g. 201234567 or +233201234567 or email"
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Enter your phone number (with or without country code) or your email address
                </p>
              </div>

              <div>
                <Label htmlFor="password" className="text-sm font-medium">Password</Label>
                <div className="relative mt-1">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Your password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <Button
                asChild
                className="w-full bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold py-3"
              >
                <Link to="/dashboard" className="flex items-center justify-center gap-2">
                  <ArrowRight className="w-4 h-4" /> Sign In
                </Link>
              </Button>
            </form>

            <div className="text-center mt-4">
              <Link to="#" className="text-sm text-gray-500 hover:text-[#006B3C] hover:underline">
                Forgot your password?
              </Link>
            </div>

            <div className="text-center mt-4 pt-4 border-t">
              <p className="text-sm text-gray-500">
                New to The Base? <Link to="/register" className="text-[#006B3C] hover:underline font-medium">Create an account</Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
