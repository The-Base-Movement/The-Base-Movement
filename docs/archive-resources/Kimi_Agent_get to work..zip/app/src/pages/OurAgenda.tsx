import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ChevronDown, ChevronUp, BookOpen, ArrowRight, GraduationCap, Building2, Factory, Landmark, Sprout } from 'lucide-react'
import { Construction } from 'lucide-react'

const agendaPillars = [
  {
    id: 'education',
    number: '01',
    title: 'Quality Education for Every Ghanaian',
    icon: GraduationCap,
    color: '#006B3C',
    summary: 'Ensure universal access to quality formal and informal education that produces informed, capable, and civically responsible Ghanaian citizens at every level of society.',
    objectives: [
      {
        title: 'Universal Access',
        items: [
          'Fully fund free quality education covering tuition, materials and meals for every child.',
          'Build or rehabilitate at least one equipped school in every community of 500+.',
          'Introduce credible scholarships for deserving students from low-income households.'
        ]
      },
      {
        title: 'Curriculum & Civic Reform',
        items: [
          'Integrate critical thinking, financial literacy, entrepreneurship and civic responsibility into the national curriculum at every level.',
          'Launch community learning centres and adult literacy programmes to reach those who missed formal schooling.'
        ]
      },
      {
        title: 'Teacher Quality',
        items: [
          'Improve teacher conditions of service, making the profession well-compensated and respected.',
          'Invest in continuous professional development, especially in science, mathematics and technical education.'
        ]
      }
    ]
  },
  {
    id: 'government',
    number: '02',
    title: 'Lean, Accountable Government',
    icon: Building2,
    color: '#CE1126',
    summary: 'Build a right-sized, fiscally disciplined government where public office is a service to the nation — not a path to personal enrichment — and where every cedi of public money is accounted for.',
    objectives: [
      {
        title: 'Right-Sizing Government',
        items: [
          'Audit all ministries and agencies within 90 days of assuming office and publish findings publicly.',
          'Reduce ministers to the constitutional minimum.',
          'Merge overlapping agencies to eliminate duplication.'
        ]
      },
      {
        title: 'Fiscal Discipline & Anti-Corruption',
        items: [
          'Enforce transparent, performance-linked public sector pay.',
          'Strengthen anti-corruption institutions.',
          'Mandate publicly accessible asset declarations for all political appointees.',
          'Prosecute all documented corruption regardless of party.'
        ]
      }
    ]
  },
  {
    id: 'industry',
    number: '03',
    title: 'Industrialisation, Tourism & Agro-Processing',
    icon: Factory,
    color: '#D4A017',
    summary: 'Drive economic growth and mass employment through three powerful engines: building factories and industries across all 16 regions, developing Ghana into a world-class tourism destination, and transforming raw agricultural produce into high-value processed goods that keep wealth and jobs inside Ghana.',
    objectives: [
      {
        title: 'Industrialisation — Factories Across All 16 Regions',
        items: [
          'Establish manufacturing plants and processing facilities in all 16 regions, beginning with five regions in the first phase.',
          'Develop industrial zones with fiscal incentives including tax holidays and import duty waivers on machinery.',
          'Prioritise regions with the highest youth unemployment.',
          'Build a pharmaceutical manufacturing hub in Gomoa Okyereko to produce medicines locally for Ghana and for export across Africa.'
        ]
      },
      {
        title: 'Tourism — Unlocking Ghana\'s Economic Potential',
        items: [
          'Transform Ghana\'s beaches, national parks — including Mole National Park — and heritage sites into world-class tourism destinations through targeted infrastructure investment.',
          'Develop the Volta Region as a dedicated creative economy and eco-tourism hub.',
          'Establish a landmark national monument to position Ghana on the global tourism map.',
          'Use tourism receipts to strengthen the Cedi and reduce pressure on foreign exchange.'
        ]
      },
      {
        title: 'Agro-Processing — Keeping Value in Ghana',
        items: [
          'Build agro-processing hubs in key agricultural zones to process cassava into ethanol and starch, plantain stems into textile fibre and paper, coconut into oil and activated carbon, and yam into pharmaceutical-grade flour.',
          'Eliminate the export of raw agricultural commodities at low prices.',
          'Ensure that every harvest creates not just farm income but factory jobs, packaging jobs, and export revenue that stays inside Ghana.'
        ]
      }
    ]
  },
  {
    id: 'infrastructure',
    number: '04',
    title: 'Quality Infrastructure — From Cities to Villages',
    icon: Construction,
    color: '#006B3C',
    summary: 'Deliver world-class roads, energy, water, and digital infrastructure across Ghana — with deliberate priority given to rural and village communities that have been left behind.',
    objectives: [
      {
        title: 'Rural Road Development',
        items: [
          'Develop a National Rural Roads Master Plan to fund construction and rehabilitation of all critical feeder roads.',
          'Ensure every farming community has an all-season road within two terms.',
          'Create a dedicated Rural Roads Maintenance Fund.'
        ]
      },
      {
        title: 'Urban & Housing',
        items: [
          'Invest in urban road networks, drainage and public transport.',
          'Develop an affordable housing programme with accessible financing for working families.'
        ]
      },
      {
        title: 'Energy & Digital',
        items: [
          'Achieve 100% household electrification within two terms.',
          'Extend broadband internet access to all districts, enabling a digital economy beyond the major cities.'
        ]
      }
    ]
  },
  {
    id: 'reform',
    number: '05',
    title: 'Comprehensive Institutional Reform',
    icon: Landmark,
    color: '#CE1126',
    summary: 'Restructure, streamline, and strengthen all public institutions so that government serves the people efficiently, transparently, and without unnecessary duplication or waste.',
    objectives: [
      {
        title: 'Restructuring Institutions',
        items: [
          'Conduct a full functional review of all state institutions in year one.',
          'Merge overlapping ministries guided by service delivery, not politics.',
          'Establish a permanent independent Public Sector Reform Commission.'
        ]
      },
      {
        title: 'Judicial & Law Enforcement',
        items: [
          'Strengthen judicial independence and speed.',
          'Reform the Ghana Police Service with better training, welfare and accountability.',
          'Create independent oversight for all law enforcement.'
        ]
      },
      {
        title: 'Electoral & Democratic Reform',
        items: [
          'Strengthen the Electoral Commission\'s independence.',
          'Introduce campaign finance legislation to limit the influence of money in democratic processes.'
        ]
      }
    ]
  },
  {
    id: 'agriculture',
    number: '06',
    title: 'Expertise-Led Agriculture Sector',
    icon: Sprout,
    color: '#D4A017',
    summary: 'Place qualified agricultural experts, scientists, and practitioners in charge of Ghana\'s food and farming sector, driving evidence-based policy, agro-processing, and genuine food security.',
    objectives: [
      {
        title: 'Expert Leadership',
        items: [
          'Appoint Ministers and senior officials based on agricultural expertise, not political loyalty.',
          'Establish an independent Agricultural Advisory Council.',
          'Deploy trained extension officers to every district.'
        ]
      },
      {
        title: 'Agro-Processing & Value Addition',
        items: [
          'Build processing hubs in key agricultural zones to produce ethanol, starch, oils and derivatives locally.',
          'Develop a National Irrigation Programme for year-round productivity.'
        ]
      },
      {
        title: 'Farmer Welfare & Food Security',
        items: [
          'Introduce a Farmer Support Programme covering subsidised inputs, crop insurance, guaranteed minimum pricing and market access.',
          'Build strategic grain reserves and mechanise farming at scale in northern regions.'
        ]
      }
    ]
  }
]

function PillarCard({ pillar }: { pillar: typeof agendaPillars[0] }) {
  const [expanded, setExpanded] = useState(false)
  const Icon = pillar.icon

  return (
    <Card className="border border-gray-200 overflow-hidden">
      <CardContent className="p-0">
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full p-6 text-left flex items-start gap-4 hover:bg-gray-50 transition-colors"
        >
          <div
            className="w-12 h-12 rounded-full flex items-center justify-center shrink-0"
            style={{ backgroundColor: `${pillar.color}15` }}
          >
            <Icon className="w-6 h-6" style={{ color: pillar.color }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold uppercase tracking-wider" style={{ color: pillar.color }}>
                Aim {pillar.number}
              </span>
            </div>
            <h3 className="text-lg font-bold text-[#1a1a1a]">{pillar.title}</h3>
            <p className="text-sm text-gray-600 mt-2 leading-relaxed">{pillar.summary}</p>
          </div>
          <div className="shrink-0 mt-1">
            {expanded ? (
              <ChevronUp className="w-5 h-5 text-gray-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-gray-400" />
            )}
          </div>
        </button>
        {expanded && (
          <div className="px-6 pb-6 pl-[72px]">
            <div className="border-t pt-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-4">
                Objectives
              </h4>
              <div className="space-y-4">
                {pillar.objectives.map((obj, idx) => (
                  <div key={idx}>
                    <h5 className="text-sm font-semibold text-[#1a1a1a] mb-2">
                      {obj.title}
                    </h5>
                    <ul className="space-y-1.5">
                      {obj.items.map((item, i) => (
                        <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#D4A017] mt-1.5 shrink-0"></span>
                          <span className="leading-relaxed">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default function OurAgenda() {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient text-white py-12 md:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-2">Aims & Objectives</h1>
          <div className="section-divider mx-auto mb-4"></div>
          <p className="text-sm uppercase tracking-widest text-gray-300 mb-2">The Base Political Movement</p>
          <p className="text-sm text-gray-400">Ghana First • Patriotism • Honesty • Discipline</p>
        </div>
      </section>

      {/* Explainer Cards */}
      <section className="py-12 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="border border-gray-200">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-[#1a1a1a] mb-3">What is an Aim?</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  An Aim is a broad, long-term statement of intent — it describes the desired end state or the overall direction a movement or organisation wishes to pursue. Aims are visionary in nature. They answer the question: "What kind of Ghana are we trying to build?" They are not time-bound or immediately measurable, but they provide the moral compass and purpose that guides all action.
                </p>
              </CardContent>
            </Card>
            <Card className="border border-gray-200">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-[#1a1a1a] mb-3">What is an Objective?</h3>
                <p className="text-sm text-gray-600 leading-relaxed">
                  An Objective is a specific, actionable, and measurable step taken in pursuit of an Aim. Objectives answer the question: "Exactly what will we do — and how?" They are concrete, time-oriented, and directly deliverable. Where an Aim sets the destination, an Objective maps the route. Every objective in this document is derived from one of THE BASE's six core Aims.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* The Six Aims */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-[#1a1a1a] mb-10">
            The Six Aims of The Base
          </h2>
          <div className="space-y-4">
            {agendaPillars.map((pillar) => (
              <PillarCard key={pillar.id} pillar={pillar} />
            ))}
          </div>
        </div>
      </section>

      {/* Covenant */}
      <section className="py-16 md:py-20 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="section-divider mx-auto mb-6"></div>
          <div className="w-12 h-12 bg-[#D4A017]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-6 h-6 text-[#D4A017]" />
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-[#1a1a1a] mb-4">
            Our Covenant with Ghana
          </h2>
          <p className="text-gray-600 leading-relaxed mb-4">
            These Aims define the Ghana we are building. These Objectives are the steps we will be held accountable to. Together, they form THE BASE's covenant with every Ghanaian who believes this country can — and must — do better.
          </p>
          <p className="text-gray-600 leading-relaxed mb-6">
            We do not offer vague promises. We offer an honest, detailed, and actionable agenda rooted in the realities of ordinary Ghanaians and the potential of an extraordinary nation.
          </p>
          <p className="text-[#D4A017] font-semibold mb-2">Ghana First. Always.</p>
          <p className="text-sm text-gray-500 mb-8">Patriotism • Honesty • Discipline</p>
          <Button
            asChild
            className="bg-[#CE1126] hover:bg-[#b30f20] text-white font-semibold px-8 py-3 text-base rounded-md"
          >
            <Link to="/register" className="flex items-center gap-2">
              Join The Movement <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
