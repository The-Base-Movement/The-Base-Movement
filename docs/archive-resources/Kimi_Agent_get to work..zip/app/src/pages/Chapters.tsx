import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { MapPin, Users, ArrowRight, Globe } from 'lucide-react'
import { Link } from 'react-router-dom'

const chapters = [
  { region: 'Greater Accra', coordinator: 'TBD', members: '45,000+' },
  { region: 'Ashanti', coordinator: 'TBD', members: '38,000+' },
  { region: 'Eastern', coordinator: 'TBD', members: '22,000+' },
  { region: 'Central', coordinator: 'TBD', members: '18,000+' },
  { region: 'Western', coordinator: 'TBD', members: '15,000+' },
  { region: 'Northern', coordinator: 'TBD', members: '12,000+' },
  { region: 'Volta', coordinator: 'TBD', members: '14,000+' },
  { region: 'Bono', coordinator: 'TBD', members: '10,000+' },
]

const diasporaChapters = [
  { country: 'United Kingdom', city: 'London', members: '8,000+' },
  { country: 'United States', city: 'New York', members: '6,000+' },
  { country: 'Germany', city: 'Berlin', members: '3,000+' },
  { country: 'Canada', city: 'Toronto', members: '2,500+' },
]

export default function Chapters() {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient text-white py-12 md:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-2">Chapters</h1>
          <p className="text-gray-300">Organized local communities across Ghana and the diaspora</p>
        </div>
      </section>

      {/* Ghana Chapters */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-8">
            <MapPin className="w-6 h-6 text-[#006B3C]" />
            <h2 className="text-2xl font-bold text-[#1a1a1a]">Ghana Chapters</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {chapters.map((chapter) => (
              <Card key={chapter.region} className="border border-gray-200 hover:shadow-md transition-all">
                <CardContent className="p-5">
                  <h3 className="font-semibold text-[#1a1a1a] mb-1">{chapter.region}</h3>
                  <p className="text-sm text-gray-500 mb-2">Coordinator: {chapter.coordinator}</p>
                  <div className="flex items-center gap-1 text-sm text-[#006B3C]">
                    <Users className="w-4 h-4" />
                    <span>{chapter.members} members</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Diaspora Chapters */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-8">
            <Globe className="w-6 h-6 text-[#D4A017]" />
            <h2 className="text-2xl font-bold text-[#1a1a1a]">Diaspora Chapters</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {diasporaChapters.map((chapter) => (
              <Card key={chapter.country} className="border border-gray-200 hover:shadow-md transition-all">
                <CardContent className="p-5">
                  <h3 className="font-semibold text-[#1a1a1a] mb-1">{chapter.city}</h3>
                  <p className="text-sm text-gray-500 mb-2">{chapter.country}</p>
                  <div className="flex items-center gap-1 text-sm text-[#D4A017]">
                    <Users className="w-4 h-4" />
                    <span>{chapter.members} members</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-[#1a1a1a] mb-4">Start or Join a Chapter</h2>
          <p className="text-gray-600 mb-6">
            Be part of the movement in your community. Whether you are in Ghana or abroad, there is a place for you.
          </p>
          <Button asChild className="bg-[#006B3C] hover:bg-[#005a32] text-white font-semibold px-6">
            <Link to="/register" className="flex items-center gap-2">
              Join The Base <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
