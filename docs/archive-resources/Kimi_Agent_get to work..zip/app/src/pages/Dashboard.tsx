import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Bell, Share2, CreditCard, ShoppingBag, BarChart3, Heart, User, ArrowRight, Clock, TrendingUp } from 'lucide-react'

export default function Dashboard() {
  return (
    <div className="py-8 px-4">
      <div className="max-w-5xl mx-auto">
        {/* Welcome Header */}
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="The Base" className="h-12 w-auto" />
            <div>
              <h1 className="text-2xl font-bold text-[#006B3C]">Welcome, Stiffler Bernard Awuah</h1>
              <p className="text-sm text-gray-500">Registration No: DI-2028-355483</p>
            </div>
          </div>
          <button className="p-2 rounded-full hover:bg-gray-100 transition-colors relative">
            <Bell className="w-5 h-5 text-gray-600" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-[#CE1126] rounded-full"></span>
          </button>
        </div>

        {/* Growth Stats */}
        <Card className="border border-gray-200 mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-[#006B3C]" />
              <h2 className="font-semibold text-[#1a1a1a]">Growth Stats</h2>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-gray-500 mb-1">
                  <Clock className="w-3 h-3" /> Joined in last 1 hour
                </div>
                <p className="text-2xl font-bold text-[#1a1a1a]">2</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-gray-500 mb-1">
                  <Clock className="w-3 h-3" /> Joined in last 24 hours
                </div>
                <p className="text-2xl font-bold text-[#D4A017]">168</p>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center gap-1 text-xs text-gray-500 mb-1">
                  <Clock className="w-3 h-3" /> Joined in last 7 days
                </div>
                <p className="text-2xl font-bold text-[#CE1126]">786</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Your Details */}
        <Card className="border border-gray-200 mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <User className="w-5 h-5 text-[#006B3C]" />
              <h2 className="font-semibold text-[#1a1a1a]">Your Details</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Full Name</span>
                  <span className="font-medium text-[#1a1a1a]">Stiffler Bernard Awuah</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Platform</span>
                  <span className="font-medium text-[#1a1a1a]">DIASPORA</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Age Range</span>
                  <span className="font-medium text-[#1a1a1a]">26-40</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-500">Registration Number</span>
                  <span className="font-medium text-[#1a1a1a]">DI-2028-355483</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Phone</span>
                  <span className="font-medium text-[#1a1a1a]">+32 +32467814742</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Gender</span>
                  <span className="font-medium text-[#1a1a1a]">MALE</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Invite Section */}
        <Card className="border border-gray-200 mb-6 bg-gradient-to-r from-[#006B3C]/5 to-[#D4A017]/5">
          <CardContent className="p-6 text-center">
            <div className="w-10 h-10 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <Share2 className="w-5 h-5 text-[#006B3C]" />
            </div>
            <h2 className="font-semibold text-[#006B3C] mb-1">Invite Others to Join The Base</h2>
            <p className="text-sm text-gray-600 mb-4">Share your unique invite link and grow the movement</p>
            <Button className="bg-[#D4A017] hover:bg-[#c49a15] text-white font-semibold">
              <Share2 className="w-4 h-4 mr-2" /> Invite & Share
            </Button>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <Link to="#" className="group">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-md transition-all">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-[#006B3C]" />
                  <span className="text-sm font-medium text-[#1a1a1a]">View Membership Card</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#006B3C] transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link to="/store" className="group">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-md transition-all">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <ShoppingBag className="w-5 h-5 text-[#CE1126]" />
                  <span className="text-sm font-medium text-[#1a1a1a]">Official Store</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#006B3C] transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link to="#" className="group">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-md transition-all">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-5 h-5 text-[#D4A017]" />
                  <span className="text-sm font-medium text-[#1a1a1a]">Opinion Polls</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#006B3C] transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link to="/donate" className="group">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-md transition-all">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Heart className="w-5 h-5 text-[#CE1126]" />
                  <span className="text-sm font-medium text-[#1a1a1a]">Donate / Support</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#006B3C] transition-colors" />
              </CardContent>
            </Card>
          </Link>

          <Link to="#" className="group">
            <Card className="border border-gray-200 hover:border-[#006B3C]/30 hover:shadow-md transition-all">
              <CardContent className="p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-[#D4A017]" />
                  <span className="text-sm font-medium text-[#1a1a1a]">Edit Profile</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-400 group-hover:text-[#006B3C] transition-colors" />
              </CardContent>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  )
}
