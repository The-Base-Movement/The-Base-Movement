import { Card, CardContent } from '@/components/ui/card'
import { Target, Users, Heart, TrendingUp } from 'lucide-react'

const impactStats = [
  { icon: Users, label: 'Members Joined', value: '355,482', color: '#006B3C' },
  { icon: Target, label: 'Chapters Active', value: '16', color: '#D4A017' },
  { icon: Heart, label: 'Donations Received', value: 'GHS 120K+', color: '#CE1126' },
  { icon: TrendingUp, label: 'Countries Reached', value: '32', color: '#006B3C' }
]

const milestones = [
  {
    date: 'January 2026',
    title: 'Movement Launch',
    description: 'The Base was officially launched as a national political movement uniting Ghanaians worldwide.'
  },
  {
    date: 'February 2026',
    title: '100,000 Members',
    description: 'Reached the first major milestone of 100,000 registered members across Ghana and the diaspora.'
  },
  {
    date: 'March 2026',
    title: 'Agenda Publication',
    description: 'Published the comprehensive six-pillar agenda for national transformation.'
  },
  {
    date: 'April 2026',
    title: '300,000 Members',
    description: 'Crossed 300,000 members with active chapters in all 16 regions of Ghana.'
  }
]

export default function Impact() {
  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient text-white py-12 md:py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl md:text-5xl font-bold mb-2">Our Impact</h1>
          <p className="text-gray-300">Proof of movement activity and national engagement</p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {impactStats.map((stat) => {
              const Icon = stat.icon
              return (
                <Card key={stat.label} className="border border-gray-200 text-center">
                  <CardContent className="p-6">
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3"
                      style={{ backgroundColor: `${stat.color}15` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: stat.color }} />
                    </div>
                    <p className="text-2xl font-bold text-[#1a1a1a] mb-1">{stat.value}</p>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold text-center text-[#1a1a1a] mb-10">
            Movement Milestones
          </h2>
          <div className="space-y-6">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-3 h-3 rounded-full bg-[#006B3C]"></div>
                  {index < milestones.length - 1 && (
                    <div className="w-0.5 flex-1 bg-[#006B3C]/30 mt-2"></div>
                  )}
                </div>
                <div className="pb-6">
                  <span className="text-xs font-semibold text-[#D4A017] uppercase tracking-wider">
                    {milestone.date}
                  </span>
                  <h3 className="text-lg font-bold text-[#1a1a1a] mt-1 mb-1">{milestone.title}</h3>
                  <p className="text-sm text-gray-600 leading-relaxed">{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
