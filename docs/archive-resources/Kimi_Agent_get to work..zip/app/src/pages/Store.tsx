import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { ShoppingBag, ArrowRight } from 'lucide-react'

const products = [
  {
    id: 1,
    name: 'The Base T-Shirt',
    price: 'GHS 80',
    description: 'Premium quality cotton t-shirt with The Base logo',
    status: 'Available'
  },
  {
    id: 2,
    name: 'Ghana First Cap',
    price: 'GHS 45',
    description: 'Embroidered cap with Ghana First slogan',
    status: 'Available'
  },
  {
    id: 3,
    name: 'Movement Wristband',
    price: 'GHS 15',
    description: 'Silicone wristband with patriotic colors',
    status: 'Available'
  },
  {
    id: 4,
    name: 'Base Notebook',
    price: 'GHS 25',
    description: 'A5 notebook with The Base branding',
    status: 'Coming Soon'
  }
]

export default function Store() {
  return (
    <div className="py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10">
          <div className="w-12 h-12 bg-[#006B3C]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag className="w-6 h-6 text-[#006B3C]" />
          </div>
          <h1 className="text-3xl font-bold text-[#1a1a1a] mb-2">Official Store</h1>
          <p className="text-gray-600">Support the movement with branded merchandise</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="border border-gray-200 hover:shadow-md transition-all">
              <CardContent className="p-6 text-center">
                <div className="w-full h-40 bg-gray-100 rounded-lg flex items-center justify-center mb-4">
                  <ShoppingBag className="w-12 h-12 text-gray-300" />
                </div>
                <h3 className="font-semibold text-[#1a1a1a] mb-1">{product.name}</h3>
                <p className="text-sm text-gray-500 mb-2">{product.description}</p>
                <p className="text-lg font-bold text-[#006B3C] mb-3">{product.price}</p>
                <Button
                  asChild
                  variant={product.status === 'Coming Soon' ? 'outline' : 'default'}
                  className={product.status === 'Coming Soon' ? '' : 'bg-[#006B3C] hover:bg-[#005a32] text-white'}
                  disabled={product.status === 'Coming Soon'}
                >
                  <Link to="#" className="flex items-center justify-center gap-2">
                    {product.status === 'Coming Soon' ? product.status : 'Add to Cart'}
                    {product.status !== 'Coming Soon' && <ArrowRight className="w-4 h-4" />}
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
